<?php
$page_title = "Prenotazioni - Studio Medico CaLeCare"; // Titolo della pagina

include_once("../Common/Connection.php");

// Capire se la sessione è di un paziente o di un dottore
$column = $_SESSION["type"] == 1 ? "ID_paziente" : "ID_dottore";
$id = $_SESSION["id"];

$sql = $conn->prepare("SELECT p.ID_prenotazione, p.Descrizione, p.Stato, p.Data_ref, CONCAT(d.Nome, ' ', d.Cognome) AS Dottore, CONCAT(pz.Nome, ' ', pz.Cognome) AS Paziente
                        FROM prenotazione p
                        INNER JOIN dottore d ON d.ID_dottore = p.ID_dottore
                        INNER JOIN paziente pz ON pz.ID_paziente = p.ID_paziente
                        WHERE p.$column = ?");
$sql->bind_param("s", $id);
$sql->execute();
$bookings = $sql->get_result();

// Query per ottenere tutti gli ID dei dottori
$sql =  $conn->prepare("SELECT ID_dottore, Nome, Cognome FROM dottore");
$sql->execute();
$doctors = $sql->get_result();

$sql->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $page_title; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="../!Immagini/Logo.png">
    <link rel="stylesheet" href="Prenotazione.css">
</head>

<body>

    <?php include_once("../Common/Header.php"); ?>
    
    <br>

    <?php if ($_SESSION["type"] == 1) { ?>
        <div class="do-container">
            <form action="Prenotazione-Add.php" method="POST" class="do-prenotazione">
                <label>Dottore:</label> <br>
                <select name="ID_dottore" required>
                    <option value="" disabled selected>-- Seleziona un dottore --</option>

                    <?php foreach ($doctors as $item) { ?>

                        <option value="<?= $item["ID_dottore"] ?>"> <?= $item["Nome"] ?> <?= $item["Cognome"] ?> </option>

                    <?php } ?>
                </select>
                <br>
                <label>Descrizione:</label> <br>
                <textarea name="Descrizione"></textarea>
                <br>
                <button type="submit" class="button-tab">Aggiungi prenotazione</button>

            </form>
        </div>
        

        <br>
        <hr>

    <?php } ?>


    <div class="container-prenotazione">
        <h1>Le tue prenotazioni</h1>
        <table>
            <tr>
                <th>
                    <?= $_SESSION["type"] == 1 ? "Dottore" : "Paziente"; ?>
                </th>
                <th>Descrizione</th>
                <th>Stato</th>
                <th>Data</th>
                <th></th>
            </tr>

            <?php foreach ($bookings as $item) { ?>

                <tr>
                    <td><?= $_SESSION["type"] == 1 ? $item["Dottore"] : $item["Paziente"]; ?></td>
                    <td><?= $item["Descrizione"] ?></td>
                    <td><?= $item["Stato"] == 0 ? "Rifiutata" : ($item["Stato"] == 1 ? "Accettata" : "In attesa...") ?></td>
                    <td><?= $item["Data_ref"] ?></td>
                    <td>
                        <?php
                        if ($_SESSION["type"] == 1) {
                        ?>
                            <form action="Prenotazione-Code.php" method="POST">
                                <input type="hidden" value="" name="status">
                                <input type="hidden" value="<?= $item["ID_prenotazione"] ?>" name="id">
                                <button type="submit" class="button-tab">Annulla prenotazione</button>
                            </form>
                        <?php
                        } else {
                        ?>
                        <div class="double-buttons">
                            <form action="Prenotazione-Code.php" method="POST">
                                    <input type="hidden" value="1" name="status">
                                    <input type="hidden" value="<?= $item["ID_prenotazione"] ?>" name="id">
                                    <button type="submit" class="button-accetta">Accetta</button>
                                </form>

                                <form action="Prenotazione-Code.php" method="POST">
                                    <input type="hidden" value="0" name="status">
                                    <input type="hidden" value="<?= $item["ID_prenotazione"] ?>" name="id">
                                    <button type="submit" class="button-rifiuta">Rifiuta</button>
                                </form>
                        </div>
                            

                        <?php
                        }
                        ?>

                    </td>
                </tr>

            <?php } ?>

        </table>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Studio Medico CaLeCare - Tutti i diritti riservati</p>
    </footer>

</body>

</html>