<?php
$page_title = "Registrazione - Studio Medico CaLeCare"; // Titolo della pagina
session_start();
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo $page_title; ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
  <link rel="icon" type="image/x-icon" href="../!Immagini/Logo.png">
  <link rel="stylesheet" href="SignUp.css">
</head>

<body>

  <form action="" method="post">
    <h2>REGISTRAZIONE</h2>

    <label for="nomeI">Nome:</label>
    <input type="text" id="nomeI" name="nomeI" value="" required><br>

    <label for="cognomeI">Cognome:</label>
    <input type="text" id="cognomeI" name="cognomeI" value="" required><br>

    <label for="email">Email:</label>
    <input type="text" id="email" name="email" value="" required><br>

    <label for="passwdI">Password:</label>
    <input type="password" id="passwdI" name="passwdI" minlength="3" required><br>

    <input type="submit" formaction="SignUp-Code.php" value="REGISTRATI"><br><br>

    <label>
      Hai già un account? <a href="../Login/Login-Page.php">Accedi</a>
    </label>

  </form>

  <!-- Footer -->
  <footer>
    <p>&copy; 2025 Studio Medico CaLeCare - Tutti i diritti riservati</p>
  </footer>

</body>

</html>