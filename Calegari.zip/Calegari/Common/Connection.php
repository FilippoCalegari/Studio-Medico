<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studio medico";

// Connessione al database
$conn = new mysqli($servername, $username, $password, $dbname);

// Controllo connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}