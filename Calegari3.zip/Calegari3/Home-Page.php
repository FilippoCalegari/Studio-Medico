<?php
  // Inizio della pagina
  $page_title = "Ambulatorio Medico"; // Titolo della pagina
  session_start();
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="Graphics.css"> <!-- Puoi aggiungere un file CSS per migliorare il design -->
</head>
<body>

    <!-- Intestazione -->
    <header>
        <div class="container">
            <h1>Ambulatorio Medico</h1>
            <nav>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Servizi</a></li>
                    <li><a href="#">Contatti</a></li>
                    <?php
                        if (!isset($_SESSION["username"])) {
                    ?>
                    <li><a href="SignUp-Page.php">Area Personale</a></li>

                    <?php
                        } else {
                    ?>
                    <li><a href="Logout-Page.php">Disconnessione</a></li>

                    <?php
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Sezione di benvenuto -->
    <section class="welcome">
        <div class="container">
            <h2>Benvenuto nel nostro Ambulatorio!</h2>
            <p>Il nostro ambulatorio è qui per offrirti assistenza medica di alta qualità. Siamo specializzati in diverse branche della medicina e siamo pronti a soddisfare le tue esigenze sanitarie.</p>
            <p>Visita il nostro sito per scoprire i servizi che offriamo e prenotare un appuntamento con i nostri esperti.</p>
        </div>
    </section>

    <!-- Sezione servizi -->
    <section class="services">
        <div class="container">
            <h2>I nostri servizi</h2>
            <ul>
                <li>Visite generiche</li>
                <li>Controllo della pressione arteriosa</li>
                <li>Analisi di laboratorio</li>
                <li>Assistenza pediatrica</li>
                <li>Medicina preventiva</li>
            </ul>
        </div>
    </section>

    <!-- Sezione contatti -->
    <section class="contact">
        <div class="container">
            <h2>Contattaci</h2>
            <p>Per maggiori informazioni o per prenotare un appuntamento, contattaci:</p>
            <ul>
                <li>Email: <a href="mailto:info@ambulatorio.com">info@ambulatorio.com</a></li>
                <li>Telefono: +39 012 3456789</li>
                <li>Indirizzo: Via della Salute, 123, Milano</li>
            </ul>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <p>&copy; 2025 Ambulatorio Medico - Tutti i diritti riservati</p>
        </div>
    </footer>

</body>
</html>
