<?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>

<h2>AMBULATORIO MEDICO: REGISTRAZIONE</h2>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
  <label for="nomeI">Nome:</label><br>
  <input type="text" id="nomeI" name="nomeI" value=""><br>

  <label for="cognomeI">Cognome:</label><br>
  <input type="text" id="cognomeI" name="cognomeI" value=""><br>

  <label for="passwdI">Password:</label><br>
  <input type="password" id="passwdI" name="passwdI" minlength="3"><br><br>

  <input type="submit" formaction="./SignUp-Code.php" value="REGISTRATI"><br><br>

  <label>Hai già un account? </label>
  <input type="submit" formaction="./Login-Page.php" value="ACCEDI"><br><br>
</form>

</body>
</html>