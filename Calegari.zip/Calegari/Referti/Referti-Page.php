<?php
$page_title = "Referti - Studio Medico CaLeCare"; // Titolo della pagina
session_start();

// Connessione al database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studio medico";
?>
<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $page_title; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="../!Immagini/Logo.png">
    <link rel="stylesheet" href="Referti.css">
</head>

<body>

    <?php include_once("../Common/Header.php"); ?>

    <div class="referti-container">
        <form action="Referti-Code.php" method="post">
            <label>Paziente:</label>
            <select name="id_paziente" id="id_paziente" required>
                <option value="" disabled selected>-- Seleziona un ID --</option>
                <?php

                $conn = new mysqli($servername, $username, $password, $dbname);

                // Verifica della connessione
                if ($conn->connect_error) {
                    die("Connessione fallita: " . $conn->connect_error);
                }

                // Query per ottenere tutti gli ID dei pazienti
                $sql = "SELECT ID_paziente, Nome, Cognome FROM paziente";
                $result = $conn->query($sql);

                // Popoliamo la combo box con gli ID dei pazienti
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . htmlspecialchars($row["ID_paziente"]) . '">' . htmlspecialchars($row["ID_paziente"]) . " - " . htmlspecialchars($row["Nome"]) . " " . htmlspecialchars($row["Cognome"]) . '</option>';
                    }
                } else {
                    echo '<option value="">Nessun paziente trovato</option>';
                }
                ?>
            </select>
            <br>
            <label>Data:</label>
            <input type="date" name="date" required><br>

            <label>Descrizione:</label>
            <textarea name="descrizione" required></textarea><br>

            <input type="submit" value="Aggiungi referto">

        </form>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Studio Medico CaLeCare - Tutti i diritti riservati</p>
    </footer>

</body>

</html>