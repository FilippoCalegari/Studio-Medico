<?php
$page_title = "Profilo Utente - Studio Medico CaLeCare";
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studio medico";

// Crea la connessione
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica la connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Prepara ed esegui la query
$nome = $_SESSION["username"];
$bool = null;

$sql = "SELECT ID_paziente, Nome, Cognome, Email FROM paziente WHERE Nome='$nome'";
$result = $conn->query($sql);

if ($result->num_rows == 1) { // Paziente riconosciuto
    $_SESSION["username"] = $nome;
    $row = $result->fetch_assoc();
    $id = $row['ID_paziente'];
    $nome = $row['Nome'];
    $cognome = $row['Cognome'];
    $email = $row['Email'];
    $bool = true;

} else {
    $sql = "SELECT ID_dottore, Nome, Cognome, Email, Specializzazione FROM dottore WHERE Nome='$nome'";
    $result = $conn->query($sql);
    
    if ($result->num_rows == 1) { // Dottore riconosciuto
        $_SESSION["username"] = $nome;
        $row = $result->fetch_assoc();
        $id = $row['ID_dottore'];
        $nome = $row['Nome'];
        $cognome = $row['Cognome'];
        $email = $row['Email'];
        $specializzazione = $row['Specializzazione'];
        $bool = false;
    }
}
?>

<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $page_title; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="../!Immagini/Logo.png">
    <link rel="stylesheet" href="User.css">
</head>

<body>

    <!-- Intestazione -->
    <header>
        <div class="container">
            <div class="title">
                <img src="../!Immagini/Logo.png">
                <h1>CaLeCare</h1>
            </div>

            <div class="service-container">
                <a href="../HomePage/Home-Page.php" class="service-card">Home</a>
                <a href="../About/About-Page.php" class="service-card">Su di Noi</a>
                <a href="#" class="service-card">Prenotazioni</a>

                <?php
                if (!isset($_SESSION["username"])) {
                ?>
                    <a href="../SignUp/SignUp-Page.php" class="service-card">Registrati</a>

                <?php
                } else {
                ?>
                    <a href="User-Page.php" class="service-card"><?php echo $_SESSION["username"] ?></a>
                <?php
                }
                ?>
            </div>
            <div class="searchbar">
                <div class="search-container">
                    <input type="text" placeholder="Cerca...">
                    <button>⌕</button>
                </div>
            </div>
        </div>
    </header>

    <main class="container">
        <div class="image-card">
            <img src="../!Immagini/Avatar.png" alt="Avatar">
        </div>

        <div class="profile-container">
            <div class="account-card">
                <h1>Area personale</h1>
                <p><strong>Nome:</strong> <?php echo htmlspecialchars($nome); ?></p>
                
                <p><strong>Cognome:</strong> <?php echo htmlspecialchars($cognome); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
                
                <?php
                    if ($bool) {
                ?>

                <p><strong>Referti:</strong><br> 
                
                <?php
                    $sql = "SELECT Data_ref, Descrizione FROM referto WHERE ID_paziente = $id";
                    $result = $conn->query($sql);
                
                    if ($result->num_rows > 0) { // Referti trovati
                        while ($row = $result->fetch_assoc()) {
                            $date =  $row["Data_ref"];
                            echo "<strong><i>Data:</i></strong> " . htmlspecialchars($date) . "<br>"; 
                            $descrizione = $row["Descrizione"];
                            echo "<strong><i>Descrizione:</i></strong> " . htmlspecialchars($descrizione) . "<br>";
                        }
                ?>
                </p>

                <?php
                    } else {
                        echo "Caro/a $nome, nessun referto trovato!";
                    }
                } else {
                ?>

                <p><strong>Specializzazione:</strong> <?php echo htmlspecialchars($specializzazione); ?></p>

                <?php
                }
                ?>

            </div>
        </div>
    </main>

    <?php
        if (!$bool) {
    ?>

    <form action="" method="post">
        <input type="submit" formaction="../Referti/Referti-Page.php" value="Aggiungi referto">
    </form>

    <form action="" method="post">
        <input type="submit" formaction="../Logout/Logout-Page.php" value="Logout">
    </form>

    <?php
        } else {
    ?>
    
    <form action="" method="post">
        <input type="submit" formaction="../Logout/Logout-Page.php" value="Logout">
    </form>        
    
    <?php
        }
    ?>
    
    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Studio Medico CaLeCare - Tutti i diritti riservati</p>
    </footer>

</body>

</html>