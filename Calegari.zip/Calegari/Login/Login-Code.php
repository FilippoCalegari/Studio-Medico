<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studio medico";

// Connessione al database
$conn = new mysqli($servername, $username, $password, $dbname);

// Controllo connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Prevenzione SQL injection e query sicura
$nome = $_POST["nomeI"];
$pwd = $_POST["passwdI"];

$sql = $conn->prepare("SELECT ID_paziente, Pwd FROM paziente WHERE Nome = ?");
$sql->bind_param("s", $nome);
$sql->execute();
$result = $sql->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();

    // Verifica password
    if (password_verify($pwd, $row["Pwd"])) {
        $_SESSION["username"] = $nome;
        header("Location: ../HomePage/Home-Page.php");
        exit();
    } else {
        echo "Password errata!";
    }
} else {
    $sql = $conn->prepare("SELECT ID_dottore, Pwd FROM dottore WHERE Nome = ?");
    $sql->bind_param("s", $nome);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
    
        // Verifica password
        if ($pwd === $row["Pwd"]) {
            $_SESSION["username"] = $nome;
            header("Location: ../HomePage/Home-Page.php");
            exit();
        } else {
            echo "Password errata!";
        }
    } else {
        echo "non trovato";
    }
} 

$sql->close();
$conn->close();
