<?php
$page_title = "Logout - Studio Medico CaLeCare"; // Titolo della pagina
session_start();
?>
<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $page_title; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="../!Immagini/Logo.png">
    <link rel="stylesheet" href="Logout.css">
</head>

<body>
    <div class="logout-container">
        <h1>LOGOUT</h1>

        <form id="loginForm" action="" method="post">
            <label>
                Sei sicuro di voler uscire?
            </label>
            <input type="submit" formaction="Logout-Code.php" value="Conferma logout"><br><br>
            <label>
                Ho sbagliato: <a href="../HomePage/Home-Page.php">Torna alla Home</a>
            </label>
        </form>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Studio Medico CaLeCare - Tutti i diritti riservati</p>
    </footer>
</body>

</html>