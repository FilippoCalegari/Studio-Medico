<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studio medico";

// Crea la connessione
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica la connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (!empty($_POST["id_dottore"]) && !empty($_POST["id_paziente"])&& !empty($_POST["date"]) && !empty($_POST["descrizione"])) {
        $id_dottore = $conn->real_escape_string($_POST["id_dottore"]);
        $id_paziente = $conn->real_escape_string($_POST["id_paziente"]);
        $data = $conn->real_escape_string($_POST["date"]);
        $descrizione = $conn->real_escape_string($_POST["descrizione"]);

        echo "ID Dottore ricevuto: " . htmlspecialchars($id_dottore) . "<br>";
        echo "ID Paziente ricevuto: " . htmlspecialchars($id_paziente) . "<br>";
        echo "Data: " . htmlspecialchars($data) . "<br>";
        echo "Descrizione: " . htmlspecialchars($descrizione) . "<br>";

        // Ora puoi eseguire l'inserimento nel database
        $sql = "INSERT INTO referto (ID_dottore, ID_paziente, Data_ref, Descrizione) VALUES ('$id_dottore', '$id_paziente', '$data', '$descrizione')";

        $conn->query($sql);
        header("Location: ../User/User-Page.php");
    }    
}


$conn->close();
?>