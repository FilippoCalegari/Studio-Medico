<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studio medico";

// Crea la connessione
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica la connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

$sql = "SELECT ID_paziente, Pwd FROM paziente WHERE (Nome='" . $_REQUEST["nomeI"]. "')";
$result = $conn->query($sql);

if ($result->num_rows == 1) { // Paziente riconosciuto
    $row = $result->fetch_assoc();

    if (password_verify($_REQUEST["passwdI"], $row["Pwd"])) {
        $_SESSION["username"] = $nome;
        header("Location: ../HomePage/Home-Page.php");
    }

} else {
    echo "Paziente non riconosciuto!";
}

$conn->close();
