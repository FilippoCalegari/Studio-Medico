<?php
// Inizio della pagina
$page_title = "Su di Noi - Studio Medico CaLeCare"; // Titolo della pagina
session_start();
?>
<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $page_title; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="../!Immagini/Logo.png">
    <link rel="stylesheet" href="About.css">
</head>

<body>

    <!-- Intestazione -->
    <header>
        <div class="container">
            <div class="title">
                <img src="../!Immagini/Logo.png">
                <h1>CaLeCare</h1>
            </div>

            <div class="service-container">
                <a href="../HomePage/Home-Page.php" class="service-card">Home</a>
                <a href="../About/About-Page.php" class="service-card">Su di Noi</a>
                <a href="#" class="service-card">Referti</a>

                <?php
                if (!isset($_SESSION["username"])) {
                ?>
                    <a href="../SignUp/SignUp-Page.php" class="service-card">Registrati</a>

                <?php
                } else {
                ?>
                    <a href="../Logout/Logout-Page.php" class="service-card"><?php echo $_SESSION["username"] ?></a>

                <?php
                }
                ?>
            </div>
            <div class="searchbar">
                <div class="search-container">
                    <input type="text" placeholder="Cerca...">
                    <button>⌕</button>
                </div>
            </div>
        </div>
    </header>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Studio Medico CaLeCare - Tutti i diritti riservati</p>
    </footer>
</body>

</html>