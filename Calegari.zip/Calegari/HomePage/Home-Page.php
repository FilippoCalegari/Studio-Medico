<?php
$page_title = "Studio Medico CaLeCare"; // Titolo della pagina
session_start();
?>
<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $page_title; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="../!Immagini/Logo.png">
    <link rel="stylesheet" href="Home-Page.css">
</head>

<body>

    <!-- Intestazione -->
    <header>
        <div class="container">
            <div class="title">
                <img src="../!Immagini/Logo.png">
                <h1>CaLeCare</h1>
            </div>

            <div class="service-container">
                <a href="Home-Page.php" class="service-card">Home</a>
                <a href="../About/About-Page.php" class="service-card">Su di Noi</a>
                <a href="#" class="service-card">Referti</a>

                <?php
                if (!isset($_SESSION["username"])) {
                ?>
                    <a href="../SignUp/SignUp-Page.php" class="service-card">Registrati</a>

                <?php
                } else {
                ?>
                    <a href="../Logout/Logout-Page.php" class="service-card"><?php echo $_SESSION["username"] ?></a>
                <?php
                }
                ?>
            </div>
            <div class="searchbar">
                <div class="search-container">
                    <input type="text" placeholder="Cerca...">
                    <button>⌕</button>
                </div>
            </div>
        </div>
    </header>

    <section class="info">
        <div class="container">
            <h2>Chi Siamo</h2>
            <p>Lo studio medico <strong>CaLeCare</strong> nasce con l'obiettivo di offrire un'assistenza sanitaria di qualità, mettendo al centro il benessere dei pazienti.</p>
            <p>Con un team di professionisti esperti e attrezzature all'avanguardia, forniamo cure mediche personalizzate per ogni esigenza.</p>
        </div>
    </section>

    <section class="mission">
        <div class="container">
            <h2>La Nostra Missione</h2>
            <p>Ci impegniamo a garantire un servizio medico basato su:</p>
            <ul>
                <li>Competenza e professionalità</li>
                <li>Innovazione tecnologica</li>
                <li>Attenzione e rispetto per il paziente</li>
                <li>Servizi accessibili e tempestivi</li>
            </ul>
        </div>
    </section>

    <section class="team">
        <div class="container">
            <h2>Il Nostro Team</h2>
            <p>Il nostro staff è composto da medici altamente qualificati in diverse specializzazioni, tra cui:</p>
            <ul>
                <li>Medicina Generale</li>
                <li>Cardiologia</li>
                <li>Ortopedia</li>
                <li>Pediatria</li>
                <li>Medicina Preventiva</li>
            </ul>
        </div>
    </section>

    <section class="contatti">
        <div class="container">
            <h2>Contattaci</h2>
            <p>Per maggiori informazioni o per prenotare una visita, puoi contattarci ai seguenti recapiti:</p>
            <ul>
                <li>Email: <a href="mailto:info@calecare.com">info@calecare.com</a></li>
                <li>Telefono: +39 012 3456789</li>
                <li>Indirizzo: Via della Salute, 123, Milano</li>
            </ul>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Studio Medico CaLeCare - Tutti i diritti riservati</p>
    </footer>

</body>

</html>