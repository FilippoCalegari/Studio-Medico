<?php
$page_title = "Home Page - Studio Medico CaLeCare"; // Titolo della pagina
session_start();
?>
<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $page_title; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="../!Immagini/Logo.png">
    <link rel="stylesheet" href="Home-Page.css">
</head>

<body>

    <?php include_once("../Common/Header.php"); ?>

    <img src="../!Immagini/Studio Medico.jpeg" alt="Studio Medico" class="hero-image">

    <!-- Sezione dei servizi -->
    <section class="services-section">
        <h2>I nostri servizi</h2>
        <div class="services-container">
            <div class="services">
                <h3>Visite specialistiche</h3>
                <p>Offriamo consulenze mediche in diverse specializzazioni.</p>
            </div>
            <div class="services">
                <h3>Analisi e diagnosi</h3>
                <p>Laboratorio di analisi con tecnologie all'avanguardia.</p>
            </div>
            <div class="services">
                <h3>Trattamenti personalizzati</h3>
                <p>Soluzioni terapeutiche adattate alle tue esigenze.</p>
            </div>
        </div>
    </section>

    <!-- Sezione contatti e orari -->
    <section class="contact-section">
        <h2>Contatti</h2>
        <p>Per informazioni e prenotazioni, puoi contattarci tramite i seguenti canali:</p>
        <ul>
            <li>Telefono: +39 35 1553 3529</li>
            <li>Email: info@calecare.it</li>
            <li>Orari: Lunedì - Venerdì: 09:00 - 18:00</li>
        </ul>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Studio Medico CaLeCare - Tutti i diritti riservati</p>
    </footer>

</body>

</html>