<?php
session_start();
session_destroy();
header("Location: Home-Page/Home-Page.php");
?>