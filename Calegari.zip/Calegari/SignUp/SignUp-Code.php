<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studio medico";

// Connessione al database
$conn = new mysqli($servername, $username, $password, $dbname);

// Controllo connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Prevenzione SQL injection
$nome = $conn->real_escape_string($_POST["nomeI"]);
$cognome = $conn->real_escape_string($_POST["cognomeI"]);
$email = $conn->real_escape_string($_POST["email"]);
$pwd = password_hash($_POST["passwdI"], PASSWORD_BCRYPT);

// Uso di prepared statement per sicurezza
$sql = $conn->prepare("INSERT INTO paziente (Nome, Cognome, Email, Pwd) VALUES (?, ?, ?, ?)");
$sql->bind_param("ssss", $nome, $cognome, $email, $pwd);

if ($sql->execute()) {
    $_SESSION["username"] = $nome;
    $_SESSION["id"] = $conn->insert_id;
    $_SESSION["type"] = 1; // Numero che indica il paziente
    header("Location: ../HomePage/Home-Page.php");
    exit();
} else {
    echo "Errore: " . $sql->error;
}

$sql->close();
$conn->close();
?>
