<?php
require('../fpdf/fpdf.php'); // Assicurati che il percorso sia corretto
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studio medico";

// Crea la connessione
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Recupera i dati del referto
if (isset($_GET['descrizione'])) {
    $descrizione = urldecode($_GET['descrizione']);
} else {
    die("Nessun referto trovato.");
}

// Classe personalizzata per il PDF
class PDF extends FPDF {
    function Header() {
        // Logo
        $this->Image('../!Immagini/Logo.png', 10, 10, 30);
        
        // Nome dello studio e indirizzo
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(190, 10, 'Studio Medico CaLeCare', 0, 1, 'C');
        
        $this->SetFont('Arial', '', 12);
        $this->Cell(190, 7, 'Via Esterna del Molino, 3 - 24040 Stezzano (BG)', 0, 1, 'C');
        $this->Cell(190, 7, 'Telefono: +39 35 1553 3529 - Email: info@calecare.it', 0, 1, 'C');
        $this->Ln(10);

        // Linea separatrice
        $this->SetLineWidth(0.5);
        $this->Line(10, 40, 200, 40);
        $this->Ln(10);
    }

    function Footer() {
        $this->SetY(-30);
        $this->SetFont('Arial', 'I', 10);
        $this->SetTextColor(100, 100, 100);
        
        // Linea separatrice
        $this->SetLineWidth(0.2);
        $this->Line(10, $this->GetY(), 200, $this->GetY());
        $this->Ln(5);

        // Informazioni legali
        $this->Cell(190, 7, 'Studio Medico CaLeCare - P.IVA: 12345678901', 0, 1, 'C');
        $this->Cell(190, 7, 'Copyright © ' . date('Y') . ' CaLeCare. Tutti i diritti riservati.', 0, 1, 'C');
        $this->Cell(190, 7, 'www.calecare.it', 0, 1, 'C');
    }
}

// Creazione PDF
$pdf = new PDF();
$pdf->AddPage();

// Titolo del referto
$pdf->SetFont('Arial', 'B', 14);
$pdf->SetFillColor(200, 220, 255);
$pdf->Cell(190, 12, 'Referto Medico', 0, 1, 'C', true);
$pdf->Ln(10);

// Sezione descrizione referto
$pdf->SetFont('Arial', '', 12);
$pdf->MultiCell(0, 8, "Descrizione del referto:\n", 0, 'L');
$pdf->SetFont('Arial', 'I', 12);
$pdf->SetTextColor(50, 50, 50);
$pdf->SetFillColor(240, 240, 240);
$pdf->MultiCell(0, 10, $descrizione, 1, 'L', true);
$pdf->Ln(10);

// Sezione firma
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, 'Firma del medico:', 0, 1, 'L');
$pdf->Ln(15);
$pdf->Cell(60, 0, '', 'B'); // Linea per la firma
$pdf->Ln(5);

$pdf->Output('D', 'Referto.pdf');
exit();
?>
