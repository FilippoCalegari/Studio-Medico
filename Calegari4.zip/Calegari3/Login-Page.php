<?php
session_start();
?>
<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ambulatorio Medico</title>
</head>
<body>

<h2>AMBULATORIO MEDICO</h2>

<form id="loginForm" action="./Login-Page.php" method="post">
    <label for="nomeI">Nome:</label><br>
    <input type="text" id="nomeI" name="nomeI" value=""><br>

    <label for="cognomeI">Cognome:</label><br>
    <input type="text" id="cognomeI" name="cognomeI" value=""><br>

    <label for="passwdI">Password:</label><br>
    <input type="password" id="passwdI" name="passwdI" minlength="3"><br><br>

    <?php
        if (!isset($_SESSION["username"])) {
    ?>
    <input type="submit" formaction="./Login-Code.php" value="ACCEDI"><br><br>
    <label>Non hai un account? </label>
    <input type="submit" formaction="./SignUp-Page.php" value="REGISTRATI"><br><br>

    <?php
        } else {
    ?>

    <input type="submit" formaction="./Logout-Page.php" value="LOGOUT">

    <?php
        }
    ?>
</form>

</body>
</html>