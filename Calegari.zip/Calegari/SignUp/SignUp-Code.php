<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studio medico";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Protezione contro SQL injection
$nome = $conn->real_escape_string($_POST["nomeI"]);
$cognome = $conn->real_escape_string($_POST["cognomeI"]);
$email = $conn->real_escape_string($_POST["email"]);
$pwd = password_hash($_POST["passwdI"], PASSWORD_BCRYPT);

$sql = "INSERT INTO paziente (Nome, Cognome, Email, Pwd)
    VALUES ('$nome', '$cognome', '$email', '$pwd')";

if ($conn->query($sql) === true) {
    $_SESSION["username"] = $_REQUEST["nomeI"];
    header("Location: ../HomePage/Home-Page.php");
} else {
    echo "Errore: " . $sql . "<br>" . $conn->error;
}

$conn->close();
