<?php
$page_title = "Prenotazioni - Studio Medico CaLeCare"; // Titolo della pagina
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studio medico";

// Connessione al database
$conn = new mysqli($servername, $username, $password, $dbname);

// Controllo connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

$id = $_POST["id"];

if ($_POST["status"] == 0 || $_POST["status"] == 1) {
    $query = "UPDATE prenotazione SET Stato = " . $_POST["status"] . " WHERE ID_prenotazione = ?"; 
} else {
    $query = "DELETE FROM prenotazione WHERE ID_prenotazione = ?";
}

$sql = $conn->prepare($query);
$sql->bind_param("s", $id);
$sql->execute();

$sql->close();
$conn->close();

header("Location: Prenotazione.php");