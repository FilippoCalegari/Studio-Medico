<?php
$page_title = "Prenotazioni - Studio Medico CaLeCare"; // Titolo della pagina
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studio medico";

// Connessione al database
$conn = new mysqli($servername, $username, $password, $dbname);

// Controllo connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Prevenzione SQL injection
$ID_dottore = $conn->real_escape_string($_POST["ID_dottore"]);
$Descrizione = $conn->real_escape_string($_POST["Descrizione"]);
$ID_paziente = $_SESSION["id"];

// Uso di prepared statement per sicurezza
$sql = $conn->prepare("INSERT INTO prenotazione (ID_dottore, Descrizione, ID_paziente) VALUES (?, ?, ?)");
$sql->bind_param("sss", $ID_dottore, $Descrizione, $ID_paziente);
$sql->execute();

$sql->close();
$conn->close();

header("Location: Prenotazione.php");