<?php
// Inizio della pagina
$page_title = "Su di Noi - Studio Medico CaLeCare"; // Titolo della pagina
session_start();
?>
<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $page_title; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="../!Immagini/Logo.png">
    <link rel="stylesheet" href="About.css">
</head>

<body>

    <?php include_once("../Common/Header.php"); ?>

    <!-- Sezione Introduzione sull'ambulatorio -->
    <section class="about-section">
        <h1>Benvenuti allo Studio Medico CaLeCare</h1>
        <p>Lo Studio Medico CaLeCare è dedicato a offrire servizi sanitari di alta qualità, con un'attenzione particolare alla salute e al benessere di ogni paziente. Il nostro team di professionisti qualificati è a disposizione per consulenze, diagnosi e trattamenti personalizzati.</p>
    </section>

    <!-- Sezione Mappa e Posizione -->
    <section class="map-section">
        <h2>Dove ci troviamo</h2>
        <div class="map-container">
            <!-- Mappa di Google, sostituire con il link della propria posizione -->
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1652.176705111651!2d9.646728267523146!3d45.65370826026087!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x478151ddd34b39a5%3A0x1f984ba00b5dc950!2sVia%20Esterna%20del%20Molino%2C%2024040%20Stezzano%20BG!5e1!3m2!1sit!2sit!4v1742333706257!5m2!1sit!2sit"
                width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
    </section>

    <!-- Sezione Dettagli sull'Ambulatorio -->
    <section class="details-section">
        <h2>Dettagli sull'Ambulatorio</h2>
        <p><strong>Orari di apertura:</strong></p>
        <ul>
            <li>Lunedì - Venerdì: 09:00 - 18:00</li>
            <li>Sabato: 09:00 - 13:00</li>
            <li>Domenica: Chiuso</li>
        </ul>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Studio Medico CaLeCare - Tutti i diritti riservati</p>
    </footer>
</body>

</html>